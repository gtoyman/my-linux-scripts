#!/bin/sh

X=1
while [ $X -ne 0 ]
do
	who > notify-who.log1
	sleep 2
	who > notify-who.log2
	result=$(diff -q notify-who.log1 notify-who.log2 | grep differ)
	if [ -z "$result" ]; then
	    	sleep 1
	else
    		mpg123 ./notify-who.mp3 
	fi
done
