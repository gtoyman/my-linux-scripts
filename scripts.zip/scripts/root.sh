#!/bin/sh
#
# THESE COMMANDS SHOULD BE RUN AS ROOT
#
# DISABLE IPV6 SYSTEM-WIDE
echo "1" > /proc/sys/net/ipv6/conf/all/disable_ipv6
# RESTART CUPS
#systemctl restart cups
