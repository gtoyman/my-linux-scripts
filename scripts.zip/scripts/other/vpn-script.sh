#!/bin/bash
sleep 5
date >> /var/log/nordvpn.log;
echo "Running NORDVPN-Script" >> /var/log/nordvpn.log;
#
# FIREWALL RULES
#
