#!/bin/bash
# Loop through all chains (INPUT, OUTPUT, FORWARD, etc.)
for chain in INPUT OUTPUT FORWARD; do
  # Get rules with 'sprokkel' in the comment and delete them by line number
  sudo iptables -L $chain -vn --line-numbers | grep sprokkel | while read -r line; do
    # Extract the line number
    line_number=$(echo $line | awk '{print $1}')
    # Delete the rule by line number
    sudo iptables -D $chain $line_number
  done
done
