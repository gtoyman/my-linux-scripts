#!/bin/sh
date >> /var/log/control-traffic.log;
echo "Running CONTROL-Traffic." >> /var/log/control-traffic.log

#sudo modprobe iptables
sudo modprobe iptable_mangle
sudo modprobe ip_conntrack

# CLEAR ALL PREVIOUS CONFIG
sudo ip route del default via 192.168.1.100 dev end0 table end0_table
sudo ip rule del fwmark 1
sudo echo > /etc/iproute2/rt_tables

# Create the routing tables for iproute2
echo "1 end0_table" | sudo tee -a /etc/iproute2/rt_tables
#cat /etc/iproute2/rt_tables

# Assign the default routes for the new tables:
sudo ip route add default via 192.168.1.100 dev end0 table end0_table

# Set Up IP Rules for DNS Traffic
sudo ip rule add fwmark 1 table end0_table

# Flush existing rules
sudo ip route flush cache

# Use iptables to Mark DNS and HTTP(S) Traffic
sudo iptables -t mangle -F
#sudo iptables -t mangle -A OUTPUT -p tcp --dport 53 -j MARK --set-mark 1
#sudo iptables -t mangle -A OUTPUT -p tcp --dport 53 -j CONNMARK --save-mark
#sudo iptables -t mangle -A OUTPUT -p udp --dport 53 -j MARK --set-mark 1
#sudo iptables -t mangle -A OUTPUT -p udp --dport 53 -j CONNMARK --save-mark

# Setup the NAT table to SOURCE-NAT DNS and HTTP(S) Traffic
sudo iptables -t nat -F
#sudo iptables -t nat -A POSTROUTING -p tcp --dport 53 -m mark --mark 1 -j SNAT --to-source 192.168.1.100
#sudo iptables -t nat -A POSTROUTING -p udp --dport 53 -m mark --mark 1 -j SNAT --to-source 192.168.1.100

# BLOCK FORWARDING FOR REPEATER/WIZ
#sudo iptables -D FORWARD -s repeater -j DROP
#sudo iptables -D FORWARD -s wiz1 -j DROP
#sudo iptables -D FORWARD -s wiz2 -j DROP
#sudo iptables -D FORWARD -s wiz3 -j DROP
#sudo iptables -D FORWARD -s wiz4 -j DROP
#sudo iptables -D FORWARD -s wiz5 -j DROP
#sudo iptables -D FORWARD -s 192.168.1.109 -j DROP
#sudo iptables -D FORWARD -s lgtv -j DROP

#sudo iptables -I FORWARD -s repeater -j DROP
#sudo iptables -I FORWARD -s wiz1 -j DROP
#sudo iptables -I FORWARD -s wiz2 -j DROP
#sudo iptables -I FORWARD -s wiz3 -j DROP
#sudo iptables -I FORWARD -s wiz4 -j DROP
#sudo iptables -I FORWARD -s wiz5 -j DROP
#sudo iptables -I FORWARD -s 192.168.1.109 -j DROP
#sudo iptables -I FORWARD -s lgtv -j DROP

# OPEN UP THE VPN GATEWAY
/home/sprokkel/vpn-gateway-start.sh

# Show ip route table list
ip route list table all | grep _table | grep end0

# Show ip rule table list
ip rule list

# Show the iptables mangle table
echo "=================="
echo "IPTABLES -t MANGLE"
echo "=================="
sudo iptables -t mangle -L OUTPUT -vn

# Show the iptables nat table
echo "==============="
echo "IPTABLES -t NAT"
echo "==============="
sudo iptables -t nat -L POSTROUTING -vn

# Show the routing table
echo "============="
echo "IP ROUTE LIST"
echo "============="
ip r

#EOF
echo "Done." >> /var/log/control-traffic.log
