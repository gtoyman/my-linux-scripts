#!/bin/sh
clear
nordvpn status
read a
clear
echo "CHAIN INPUT"
sudo iptables -L INPUT -vn
read a
clear
echo "CHAIN OUTPUT"
sudo iptables -L OUTPUT -vn
read a
clear
echo "CHAIN FORWARD"
sudo iptables -L FORWARD -vn
read a
clear
echo "CHAIN POSTROUTING"
sudo iptables -t nat -L POSTROUTING -vn
