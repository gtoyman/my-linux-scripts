#!/bin/sh
tail -f /var/log/syslog | grep --color=auto "gnome-remote" &
journalctl -f -u ssh &
tail -f /var/log/syslog | grep --color=auto "UFW BLOCK" | grep -v "SRC=192.168.1." & 
