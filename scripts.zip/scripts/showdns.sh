clear
echo "ETHERNET"
nmcli device show end0 | grep DNS
echo "WIFI"
nmcli device show wlp1s0f0 | grep DNS
read a
clear
echo "RESOLVECTL"
resolvectl status
