#!/bin/sh
sudo date >> /var/log/vpn-gateway.log;
sudo echo -n "Adding FIREWALL RULES FOR NAT. " | tee -a /var/log/vpn-gateway.log
sleep 3

# INPUT CHAIN
sudo iptables -P INPUT DROP	# SET INPUT POLICY TO DROP

sudo iptables -I INPUT -p tcp -s 192.168.1.0/24 -j ACCEPT 	# ALLOW ACCESS FROM LAN TCP
sudo iptables -I INPUT -p udp -s 192.168.1.0/24 -j ACCEPT 	# ALLOW ACCESS FROM LAN UDP
#sudo iptables -I INPUT -p icmp -s 192.168.1.0/24 -j ACCEPT 	# ALLOW ACCESS FROM LAN ICMP
sudo iptables -I INPUT -s 192.168.1.159 -j DROP

# ENABLE CONNECTION TRACKING: INCOMING IS ONLY ALLOWED WHEN THERE'S FIRST OUTGOING TRAFFIC.
iptables -A INPUT -m conntrack --ctstate INVALID -j DROP
iptables -A INPUT -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT

sudo iptables -A INPUT -i lo -j ACCEPT 	# ALLOW ACCESS FROM LOOPBACK INTERFACE.

# OUTPUT CHAIN
sudo iptables -P OUTPUT ACCEPT 		# SET OUTPUT POLICY TO ACCEPT
sudo iptables -I OUTPUT -p tcp --dport 123 -j DROP	# DENY OUTGOING NTP ACCESS

# FORWARD CHAIN
sudo iptables -P FORWARD DROP	# SET FORWARD POLICY TO DROP

# ALLOW LAN ACCESS & DENY SPECIFIC CLIENTS
sudo iptables -I FORWARD -s 192.168.1.0/24 -j ACCEPT -m comment --comment "FORWARD LAN TRAFFIC OUTGOING"
sudo iptables -I FORWARD -d 192.168.1.0/24 -j ACCEPT -m comment --comment "FORWARD LAN TRAFFIC INCOMING"
sudo iptables -I FORWARD -s 192.168.1.101 -j DROP  -m comment --comment "DROP FORWARD TRAFFIC FOR LGTV"
sudo iptables -I FORWARD -s 192.168.1.159 -j DROP  -m comment --comment "DROP FORWARD TRAFFIC FOR PHONE"

# NAT CHAIN
# ALLOW CLIENTS THROUGH THE GATEWAY.
#sudo iptables -t nat -I POSTROUTING -s 192.168.1.0/24 -o nordtun -j MASQUERADE #(WHOLE LAN)
#sudo iptables -t nat -I POSTROUTING -s 192.168.1.101 -o nordtun -j MASQUERADE #(LGTV)
sudo iptables -t nat -I POSTROUTING -s 192.168.1.103 -o nordtun -j MASQUERADE
sudo iptables -t nat -I POSTROUTING -s 192.168.1.104 -o nordtun -j MASQUERADE
sudo iptables -t nat -I POSTROUTING -s 192.168.1.105 -o nordtun -j MASQUERADE
sudo iptables -t nat -I POSTROUTING -s 192.168.1.106 -o nordtun -j MASQUERADE
sudo iptables -t nat -I POSTROUTING -s 192.168.1.150 -o nordtun -j MASQUERADE
sudo iptables -t nat -I POSTROUTING -s 192.168.1.151 -o nordtun -j MASQUERADE
sudo iptables -t nat -I POSTROUTING -s 192.168.1.152 -o nordtun -j MASQUERADE
sudo iptables -t nat -I POSTROUTING -s 192.168.1.153 -o nordtun -j MASQUERADE
sudo iptables -t nat -I POSTROUTING -s 192.168.1.154 -o nordtun -j MASQUERADE
sudo iptables -t nat -I POSTROUTING -s 192.168.1.155 -o nordtun -j MASQUERADE
sudo iptables -t nat -I POSTROUTING -s 192.168.1.156 -o nordtun -j MASQUERADE
sudo iptables -t nat -I POSTROUTING -s 192.168.1.157 -o nordtun -j MASQUERADE
sudo iptables -t nat -I POSTROUTING -s 192.168.1.158 -o nordtun -j MASQUERADE
sudo iptables -t nat -I POSTROUTING -s 192.168.1.159 -o nordtun -j MASQUERADE
sudo iptables -t nat -I POSTROUTING -s 192.168.1.160 -o nordtun -j MASQUERADE
sudo iptables -t nat -I POSTROUTING -s 192.168.1.161 -o nordtun -j MASQUERADE
sudo iptables -t nat -I POSTROUTING -s 192.168.1.162 -o nordtun -j MASQUERADE
sudo iptables -t nat -I POSTROUTING -s 192.168.1.163 -o nordtun -j MASQUERADE
sudo iptables -t nat -I POSTROUTING -s 192.168.1.164 -o nordtun -j MASQUERADE
sudo iptables -t nat -I POSTROUTING -s 192.168.1.165 -o nordtun -j MASQUERADE

# PORT TRIGGERING DROPPINGS PROTECTION AGAINST PORTSCANS
sudo iptables -I INPUT -p tcp --dport 500 -m recent --name bad_ip --set
sudo iptables -I INPUT -m recent --name bad_ip --rcheck --seconds 300 --hitcount 1 -j DROP

# IPV6 CHAINS
sudo ip6tables -F INPUT
sudo ip6tables -P INPUT DROP

sudo echo "NordVPN GATEWAY IS ACTIVE." >> /var/log/vpn-gateway.log
