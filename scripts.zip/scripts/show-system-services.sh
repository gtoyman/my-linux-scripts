systemctl list-units | grep service | grep running
