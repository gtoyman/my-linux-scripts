#!/bin/sh
ss -o state all dport = ssh or sport = ssh
